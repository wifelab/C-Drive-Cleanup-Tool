﻿@echo off
chcp 65001 >nul
title DiskViz 磁盘可视化清理助手
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js not found. Please install Node.js first: https://nodejs.org/
  pause
  exit /b 1
)
echo.
echo  DiskViz is starting ... the browser will open automatically.
echo  IMPORTANT: keep this window OPEN while using DiskViz.
echo  Closing this window stops the program. If the page shows "cannot connect",
echo  re-run start.bat and refresh the page.
echo.
node server.js
echo.
echo  Program exited. If it says "port is in use", open http://127.0.0.1:4173 directly.
pause >nul
