# DiskViz recycle helper - sends files/dirs to the Windows Recycle Bin.
# Zero dialogs: SHFileOperation with FOF_SILENT|FOF_NOCONFIRMATION|FOF_NOERRORUI|FOF_ALLOWUNDO.
# ASCII-only on purpose (PowerShell 5.1 parses .ps1 as ANSI/GBK; Chinese literals break it).
# Usage: powershell -NoProfile -ExecutionPolicy Bypass -File recycle-bin.ps1 <input.json> <output.json>
param([string]$JsonPath, [string]$OutPath)
$ErrorActionPreference = 'Stop'

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class DshRecycle {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct SHFILEOPSTRUCT {
    public IntPtr hwnd;
    public uint wFunc;
    public string pFrom;
    public string pTo;
    public ushort fFlags;
    public int fAnyOperationsAborted;
    public IntPtr hNameMappings;
    public string lpszProgressTitle;
  }
  [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
  public static extern int SHFileOperation(ref SHFILEOPSTRUCT lpFileOp);
  public static int SendToRecycle(string doubleNullPaths) {
    SHFILEOPSTRUCT op = new SHFILEOPSTRUCT();
    op.wFunc = 3; // FO_DELETE
    op.pFrom = doubleNullPaths;
    // FOF_SILENT(0x4) | FOF_NOCONFIRMATION(0x10) | FOF_ALLOWUNDO(0x40) | FOF_NOERRORUI(0x400) | FOF_NOCONFIRMMKDIR(0x200)
    op.fFlags = 0x4 | 0x10 | 0x40 | 0x400 | 0x200;
    return SHFileOperation(ref op);
  }
}
"@

$raw = [System.IO.File]::ReadAllText($JsonPath, [System.Text.Encoding]::UTF8)
$items = $raw | ConvertFrom-Json
$results = New-Object System.Collections.ArrayList
$pending = New-Object System.Collections.ArrayList

foreach ($p in $items.paths) {
  $size = 0L
  try { $size = (Get-Item -LiteralPath $p -Force).Length } catch { }
  if ($size -gt 5GB) {
    [void]$results.Add(@{ p = $p; ok = $false; err = "TOO_LARGE" })
  } else {
    [void]$pending.Add($p)
  }
}

$BATCH = 400
for ($i = 0; $i -lt $pending.Count; $i += $BATCH) {
  $count = [Math]::Min($BATCH, $pending.Count - $i)
  $chunk = $pending.GetRange($i, $count)
  $list = ($chunk -join [string][char]0) + [string][char]0 + [string][char]0
  try { [void][DshRecycle]::SendToRecycle($list) } catch { }
  Start-Sleep -Milliseconds 400
  foreach ($p in $chunk) {
    if (Test-Path -LiteralPath $p) {
      [void]$results.Add(@{ p = $p; ok = $false; err = "LOCKED" })
    } else {
      [void]$results.Add(@{ p = $p; ok = $true; err = "" })
    }
  }
}

$json = $results | ConvertTo-Json -Compress
[System.IO.File]::WriteAllText($OutPath, $json, [System.Text.Encoding]::UTF8)
Write-Output ("DONE " + $results.Count)
