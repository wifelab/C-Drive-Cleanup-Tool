// DiskViz 磁盘可视化清理助手 —— 后端
// 零外部依赖：Node 内置模块实现。用法：node server.js （默认端口 4173）
const http = require("http");
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const os = require("os");
const { spawn, spawnSync } = require("child_process");

const PORT = Number(process.env.PORT || 4173);
const DEFAULT_ROOT = process.env.SCAN_ROOT || "C:\\";
const APP_DIR = __dirname;
const EXE_DIR = path.dirname(process.execPath);
// 打包场景（SEA exe）下 __dirname 可能不在真实磁盘：优先探测可用的资源目录
function resolveAssetDir() {
  for (const dir of [APP_DIR, EXE_DIR]) {
    try { if (fs.existsSync(path.join(dir, "public", "index.html"))) return dir; } catch { /* 尝试下一个 */ }
  }
  return APP_DIR;
}
const ASSET_DIR = resolveAssetDir();
const PUBLIC_DIR = path.join(ASSET_DIR, "public");
// 部署到只读位置（Program Files / exe 包内）时，回收站落到用户数据目录
let TRASH_DIR = path.join(ASSET_DIR, ".trash");
try {
  fs.accessSync(ASSET_DIR, fs.constants.W_OK);
} catch {
  TRASH_DIR = path.join(os.homedir(), ".diskviz", "trash");
}
fs.mkdirSync(TRASH_DIR, { recursive: true });
// PowerShell 回收站脚本：子进程无法读打包进 exe 的虚拟文件，启动时落到真实磁盘
let PS_FILE = path.join(ASSET_DIR, "recycle-bin.ps1");
// Node SEA（单文件 exe）支持：从嵌入资源取文件
let SEA = null;
try { SEA = require("node:sea"); } catch { SEA = null; }
const IS_SEA = !!(SEA && SEA.isSea);
try {
  if (IS_SEA && SEA && typeof SEA.getAsset === "function") {
    const real = path.join(TRASH_DIR, "recycle-bin.ps1");
    fs.writeFileSync(real, Buffer.from(SEA.getAsset("recycle.ps1")));
    PS_FILE = real;
  } else if (!fs.existsSync(PS_FILE) && fs.existsSync(path.join(APP_DIR, "recycle-bin.ps1"))) {
    const real = path.join(TRASH_DIR, "recycle-bin.ps1");
    fs.writeFileSync(real, fs.readFileSync(path.join(APP_DIR, "recycle-bin.ps1")));
    PS_FILE = real;
  }
} catch { /* 忽略 */ }

// 永不因单个异常退出：记录并继续服务（避免扫描途中偶发错误导致整个进程挂掉）
process.on("unhandledRejection", (e) => {
  console.error("[unhandledRejection]", e && e.stack || e);
});
process.on("uncaughtException", (e) => {
  console.error("[uncaughtException]", e && e.stack || e);
});

// ---------- 路径安全 ----------
const norm = (p) => path.resolve(p).toLowerCase();
// 扫描时整体跳过的路径：系统回收站（$R 乱码文件）、应用自身目录、应用内回收站、系统卷信息
const SCAN_SKIP = [
  norm("C:\\$Recycle.Bin"),
  norm("C:\\System Volume Information"),
  norm(APP_DIR),
  norm(TRASH_DIR),
];
const isScanSkip = (p) => {
  const n = norm(p);
  return SCAN_SKIP.some((s) => n === s || n.startsWith(s + "\\"));
};
// 受保护根：这些路径及其下内容一律禁止删除
const PROTECTED = [
  "c:\\", "c:\\windows", "c:\\program files", "c:\\program files (x86)",
  "c:\\programdata", "c:\\$recycle.bin", "c:\\system volume information",
  "c:\\recovery", "c:\\recoveryimage", "c:\\sources", "c:\\perflogs",
  "c:\\users\\default", "c:\\users\\public", norm(TRASH_DIR),
  norm(APP_DIR), // 本应用自身目录（含回收站）不可删
];
const isProtected = (p) => {
  const n = norm(p);
  return PROTECTED.some((r) => n === r || n.startsWith(r + "\\"));
};
const onDrive = (p) => /^[a-zA-Z]:[\\/]/.test(path.resolve(p));

// ---------- 工具 ----------
function fmtSize(n) {
  if (n == null || Number.isNaN(n)) return "0 B";
  const u = ["B", "KB", "MB", "GB", "TB", "PB"];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (n >= 100 ? n.toFixed(0) : n.toFixed(1)) + " " + u[i];
}
function fmtTime(ms) {
  const d = new Date(ms);
  const p = (x) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function safeName(s) { return String(s).replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").slice(0, 80); }

// ---------- 扫描状态 ----------
let scan = null; // { running, root, startedAt, doneDirs, doneFiles, bytes, current, cancelled, error }
let tree = null; // { dirs: Map<path, node>, largest: [], junk: [], important: [], summary }
const LARGEST_CAP = 5000;
const JUNK_CAP = 3000;
const IMPORTANT_CAP = 3000;

// 最小堆（按 size），用于维护 top-N 大文件
function makeHeap(cap) {
  const arr = [];
  const less = (a, b) => a.size < b.size;
  const up = (i) => { while (i > 0) { const p = (i - 1) >> 1; if (less(arr[i], arr[p])) break; [arr[i], arr[p]] = [arr[p], arr[i]]; i = p; } };
  const down = (i) => { for (;;) { let l = 2 * i + 1, r = l + 1, m = i; if (l < arr.length && less(arr[m], arr[l])) m = l; if (r < arr.length && less(arr[m], arr[r])) m = r; if (m === i) break; [arr[m], arr[i]] = [arr[i], arr[m]]; i = m; } };
  return {
    push(x) { if (arr.length < cap) { arr.push(x); up(arr.length - 1); } else if (x.size > arr[0].size) { arr[0] = x; down(0); } },
    sorted() { return arr.slice().sort((a, b) => b.size - a.size); },
  };
}

// ---------- 无用文件识别规则（保守，只针对明确安全的缓存/临时区） ----------
const JUNK_DIR_RE = [
  /\\windows\\temp(?:\\|$)/i,
  /\\appdata\\local\\temp(?:\\|$)/i,
  /\\windows\\prefetch(?:\\|$)/i,
  /\\windows\\softwaredistribution\\download(?:\\|$)/i,
  /\\windows\\logs\\cbs(?:\\|$)/i,
  /\\windows\\minidump(?:\\|$)/i,
  /\\appdata\\local\\crashdumps(?:\\|$)/i,
  /\\appdata\\local\\microsoft\\windows\\inetcache(?:\\|$)/i,
  /\\appdata\\local\\microsoft\\windows\\explorer(?:\\|$)/i, // 缩略图缓存
  /\\appdata\\local\\google\\chrome\\user data\\[^\\]*\\cache(?:\\|$)/i,
  /\\appdata\\local\\microsoft\\edge\\user data\\[^\\]*\\cache(?:\\|$)/i,
  /\\appdata\\local\\npm-cache(?:\\|$)/i,
  /\\appdata\\local\\pnpm\\cache(?:\\|$)/i,
  /\\pip\\cache(?:\\|$)/i,
  /\\appdata\\local\\yarn\\cache(?:\\|$)/i,
];
const JUNK_EXT_RE = /\.(tmp|temp|bak|old|dmp|dump|log|etl|blf|regtrans-ms)$/i;
const JUNK_NAME_RE = /^(~?~\$|thumbs\.db$|\.ds_store$|desktop\.ini$)/i; // desktop.ini 特殊处理（见下）
function junkReason(dir) {
  for (const re of JUNK_DIR_RE) if (re.test(dir)) return "缓存/临时目录";
  return null;
}

// ---------- 重要文件识别规则 ----------
const IMPORTANT_PREFIX = [
  ["c:\\windows\\system32", "系统核心组件"],
  ["c:\\windows\\system", "系统核心组件"],
  ["c:\\windows\\syswow64", "系统核心组件"],
  ["c:\\program files", "系统程序"],
  ["c:\\program files (x86)", "系统程序"],
  ["c:\\programdata", "程序数据"],
];
const IMPORTANT_USER_DIR = [
  ["\\documents", "个人文档"],
  ["\\pictures", "个人图片"],
  ["\\videos", "个人视频"],
  ["\\music", "个人音乐"],
  ["\\downloads", "下载目录"],
  ["\\.ssh", "SSH 密钥"],
  ["\\.gnupg", "GPG 密钥"],
  ["\\.gitconfig", "Git 配置"],
  ["\\.npmrc", "npm 配置"],
];
// 游戏存档目录特征（Steam userdata / My Games / Saved Games / UE 的 SaveGames 等）
const GAME_SAVE_RE = [
  /\\(?:steam\\userdata|my games|saved games|savegames|save data|savegame)(?:\\|$)/i,
  /\\(?:userdata\\\d+\\\d+\\remote)(?:\\|$)/i,
  /\\appdata\\local(?:low)?\\[^\\]+\\saved\\savegames(?:\\|$)/i,
];
const isGameSaveDir = (dir) => GAME_SAVE_RE.some((re) => re.test(dir));
const IMPORTANT_EXT = /\.(json|ya?ml|conf|config|ini|cfg|env|pfx|p12|key|pem|crt|cer|sqlite|sqlite3|db|accdb|docx?|xlsx?|pptx?|pdf|zip|7z|rar|tar|gz|iso|vhd|vhdx|ova|qcow2)$/i;
function importantMark(dir, file, size, mtimeMs) {
  const n = norm(path.join(dir, file));
  for (const [prefix, label] of IMPORTANT_PREFIX) if (n.startsWith(prefix + "\\")) return label;
  // 游戏存档单独一类（优先于个人文档等，因为很多存档就在 Documents 下）
  if (isGameSaveDir(dir)) return "游戏存档";
  // 桌面单独一类
  if (dir.toLowerCase().endsWith("\\desktop")) return "桌面文件";
  const lowerDir = dir.toLowerCase();
  for (const [seg, label] of IMPORTANT_USER_DIR) if (lowerDir.endsWith(seg)) return label;
  const now = Date.now();
  if (now - mtimeMs < 7 * 864e5 && size > 1024 * 1024) return "近期修改(7天内)";
  if (IMPORTANT_EXT.test(file)) return "常用文档/配置";
  return null;
}

// ---------- 扫描引擎（有界并发，跳过符号链接与无权限目录） ----------
function startScan(root) {
  if (scan && scan.running) return { ok: false, error: "扫描正在进行中" };
  const CONC = 48;
  scan = { running: true, root, startedAt: Date.now(), doneDirs: 0, doneFiles: 0, bytes: 0, current: "", cancelled: false, error: null };
  const dirs = new Map();
  const largest = makeHeap(LARGEST_CAP);
  const junk = [];
  const important = [];      // 其他类别（按大小截断）
  const gameSaveFiles = [];  // 游戏存档：独立桶，保证不被大文件挤掉
  const desktopFiles = [];   // 桌面文件：独立桶
  const queue = [root];
  const rootNode = { parent: null, size: 0, fileCount: 0, children: [] };
  dirs.set(norm(root), rootNode);
  let q = 0;
  let active = 0;
  let finished = false;
  let resolveDone;
  const donePromise = new Promise((r) => (resolveDone = r));

  const maybeFinish = () => {
    if (!finished && active === 0 && q >= queue.length) { finished = true; resolveDone(); }
  };
  const waitTick = () => new Promise((r) => setImmediate(r));

  async function worker() {
    for (;;) {
      if (scan.cancelled || finished) return;
      if (q < queue.length) {
        const dirPath = queue[q++];
        active++;
        try {
          scan.current = dirPath;
          scan.doneDirs++;
          let entries;
          try { entries = await fsp.readdir(dirPath, { withFileTypes: true }); } catch { continue; }
          const node = dirs.get(norm(dirPath));
          if (!node) continue; // 防御：父目录未登记时跳过
          const jr = junkReason(dirPath);
          for (const e of entries) {
            if (scan.cancelled) return;
            if (e.isSymbolicLink()) continue;
            const p = path.join(dirPath, e.name);
            if (isScanSkip(p)) continue; // 跳过系统回收站/应用自身等，防止 $R 乱码文件入树
            if (e.isDirectory()) {
              const child = { parent: norm(dirPath), size: 0, fileCount: 0, children: [] };
              dirs.set(norm(p), child);
              node.children.push({ name: e.name, path: p });
              queue.push(p);
            } else if (e.isFile()) {
              let st;
              try { st = await fsp.stat(p); } catch { continue; }
              node.size += st.size;
              node.fileCount++;
              scan.doneFiles++;
              scan.bytes += st.size;
              if (st.size >= 1024 * 1024) {
                largest.push({ path: p, name: e.name, size: st.size, mtime: st.mtimeMs });
              }
              if (jr && junk.length < JUNK_CAP) {
                junk.push({ path: p, name: e.name, size: st.size, mtime: st.mtimeMs, reason: jr });
              }
              const im = importantMark(dirPath, e.name, st.size, st.mtimeMs);
              if (im === "游戏存档") { if (gameSaveFiles.length < 5000) gameSaveFiles.push({ path: p, name: e.name, size: st.size, mtime: st.mtimeMs, mark: im }); }
              else if (im === "桌面文件") { if (desktopFiles.length < 5000) desktopFiles.push({ path: p, name: e.name, size: st.size, mtime: st.mtimeMs, mark: im }); }
              else if (im && important.length < IMPORTANT_CAP) { important.push({ path: p, name: e.name, size: st.size, mtime: st.mtimeMs, mark: im }); }
            }
          }
        } catch (e) {
          console.error("[scan] 目录处理异常（已跳过）:", dirPath, e && e.message);
        } finally {
          active--;
          maybeFinish();
        }
      } else {
        if (active === 0) { maybeFinish(); return; }
        await waitTick();
      }
    }
  }

  const workers = Array.from({ length: CONC }, () => worker());
  donePromise.then(() => {
    if (scan.cancelled) { scan.running = false; scan.endedAt = Date.now(); return; }
    try { finalize(dirs, largest, junk, important, gameSaveFiles, desktopFiles); }
    catch (e) { console.error("[scan] 结果汇总异常:", e && e.stack || e); scan.running = false; scan.error = String(e && e.message || e); }
  });
  return { ok: true };
}

function finalize(dirs, largest, junk, important, gameSaveFiles, desktopFiles) {
  // 自底向上聚合（Map 插入序 = 父先于子，逆序 = 子先于父）
  const keys = [...dirs.keys()];
  for (let i = keys.length - 1; i >= 0; i--) {
    const node = dirs.get(keys[i]);
    if (node.parent) {
      const par = dirs.get(node.parent);
      if (par) { par.size += node.size; par.fileCount += node.fileCount; }
    }
  }
  junk.sort((a, b) => b.size - a.size);
  important.sort((a, b) => b.size - a.size);
  gameSaveFiles.sort((a, b) => b.size - a.size);
  desktopFiles.sort((a, b) => b.size - a.size);
  let totalSize = 0, totalFiles = 0, totalDirs = 0;
  for (const node of dirs.values()) {
    totalDirs++;
    if (node.parent === null) { totalSize = node.size; totalFiles = node.fileCount; }
  }
  // 游戏存档 / 桌面文件 独立成区，其余按大小
  tree = { dirs, largest: largest.sorted(), junk, important, gameSaves: gameSaveFiles, desktop: desktopFiles, summary: { totalSize, totalFiles, totalDirs, root: scan.root } };
  scan.running = false;
  scan.done = true;
  scan.endedAt = Date.now();
}

function stopScan() { if (scan && scan.running) { scan.cancelled = true; scan.running = false; scan.endedAt = Date.now(); return { ok: true }; } return { ok: false, error: "没有正在进行的扫描" }; }

// ---------- 树图数据 ----------
function treeChildren(dir) {
  const key = norm(dir);
  const node = tree?.dirs.get(key);
  if (!node) return null;
  const kids = node.children
    .map((c) => { const cn = tree.dirs.get(norm(c.path)); return { name: c.name, path: c.path, size: cn ? cn.size : 0, fileCount: cn ? cn.fileCount : 0, isDir: true }; })
    .sort((a, b) => b.size - a.size);
  // 折叠过小子项
  const LIMIT = 60;
  let children = kids, other = null;
  if (kids.length > LIMIT) {
    const head = kids.slice(0, LIMIT - 1);
    const rest = kids.slice(LIMIT - 1);
    const restSize = rest.reduce((s, x) => s + x.size, 0);
    other = { name: `其它 ${rest.length} 项`, path: dir, size: restSize, fileCount: 0, isDir: true, aggregated: true };
    children = [...head, other];
  }
  return { name: path.basename(dir) || dir, path: dir, size: node.size, fileCount: node.fileCount, children, other };
}

// ---------- 回收站（软删除：移动到应用内 .trash，可撤回） ----------
function trashManifest(opId) { return path.join(TRASH_DIR, opId, "manifest.json"); }
function listTrash() {
  if (!fs.existsSync(TRASH_DIR)) return [];
  const ops = [];
  for (const opId of fs.readdirSync(TRASH_DIR)) {
    const mf = trashManifest(opId);
    if (!fs.existsSync(mf)) continue;
    try {
      const m = JSON.parse(fs.readFileSync(mf, "utf8"));
      ops.push({ id: opId, time: m.time, items: m.items });
    } catch { /* 忽略损坏条目 */ }
  }
  ops.sort((a, b) => (b.time || 0) - (a.time || 0));
  return ops;
}

async function deletePaths(paths) {
  const opId = Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 6);
  const opDir = path.join(TRASH_DIR, opId);
  await fsp.mkdir(opDir, { recursive: true });
  const ok = [], fail = [];
  for (const raw of paths) {
    const p = path.resolve(raw);
    if (!onDrive(p)) { fail.push({ path: raw, error: "不在系统盘" }); continue; }
    if (isProtected(p)) { fail.push({ path: raw, error: "受保护路径，禁止删除" }); continue; }
    if (!fs.existsSync(p)) { fail.push({ path: raw, error: "路径不存在" }); continue; }
    let target = path.join(opDir, safeName(path.basename(p)));
    let n = 1;
    while (fs.existsSync(target)) {
      const ext = path.extname(target);
      target = path.join(opDir, path.basename(target, ext) + ` (${n})` + ext);
      n++;
    }
    let sz = 0;
    try { sz = (await fsp.stat(p)).size; } catch { /* 目录或瞬时消失 */ }
    try {
      await fsp.rename(p, target);
      ok.push({ path: raw, trashPath: target, size: sz });
    } catch (e) {
      fail.push({ path: raw, error: e.code === "EPERM" || e.code === "EACCES" ? "权限不足（可能被占用或需要管理员）" : e.message });
    }
  }
  if (ok.length) {
    const manifest = { time: Date.now(), items: ok.map((i) => ({ originalPath: i.path, trashPath: i.trashPath })) };
    fs.writeFileSync(trashManifest(opId), JSON.stringify(manifest, null, 2));
  } else {
    await fsp.rm(opDir, { recursive: true, force: true });
  }
  return { ok, fail, opId };
}

async function restoreItems(items) {
  // items: [{trashPath, originalPath}]
  const ok = [], fail = [];
  for (const it of items) {
    const src = path.resolve(it.trashPath);
    if (!src.startsWith(path.join(TRASH_DIR, ""))) { fail.push({ path: it.trashPath, error: "不在回收站" }); continue; }
    if (!fs.existsSync(src)) { fail.push({ path: it.trashPath, error: "文件不存在（可能已恢复）" }); continue; }
    let dest = path.resolve(it.originalPath);
    if (fs.existsSync(dest)) {
      const ext = path.extname(dest);
      dest = path.join(path.dirname(dest), path.basename(dest, ext) + " (已恢复)" + ext);
    }
    try {
      await fsp.mkdir(path.dirname(dest), { recursive: true });
      await fsp.rename(src, dest);
      ok.push({ from: it.trashPath, to: dest });
    } catch (e) { fail.push({ path: it.trashPath, error: e.message }); }
  }
  // 从 manifest 中移除已恢复项；空批次直接删除目录
  if (ok.length) {
    for (const it of items) {
      const mf = path.join(TRASH_DIR, path.relative(TRASH_DIR, path.dirname(path.resolve(it.trashPath))), "manifest.json");
      if (!fs.existsSync(mf)) continue;
      try {
        const m = JSON.parse(fs.readFileSync(mf, "utf8"));
        const before = m.items.length;
        m.items = m.items.filter((x) => path.resolve(x.trashPath) !== path.resolve(it.trashPath) || path.resolve(x.originalPath) !== path.resolve(it.originalPath));
        if (m.items.length !== before) {
          if (m.items.length) fs.writeFileSync(mf, JSON.stringify(m, null, 2));
          else { fs.rmSync(path.dirname(mf), { recursive: true, force: true }); }
        }
      } catch { /* 忽略 */ }
    }
  }
  return { ok, fail };
}

async function undoLast() {
  const ops = listTrash();
  if (!ops.length) return { ok: false, error: "回收站为空" };
  const op = ops[0];
  const r = await restoreItems(op.items);
  if (r.ok.length) {
    await fsp.rm(path.join(TRASH_DIR, op.id), { recursive: true, force: true });
  }
  return { ok: true, restored: r.ok.length, failed: r.fail, opId: op.id };
}

async function emptyTrash() {
  if (!fs.existsSync(TRASH_DIR)) return { ok: true, removed: 0 };
  const ops = listTrash();
  await fsp.rm(TRASH_DIR, { recursive: true, force: true });
  await fsp.mkdir(TRASH_DIR, { recursive: true });
  return { ok: true, removed: ops.length };
}

// ---------- 删除到 Windows 系统回收站（二选一中的"系统回收站"） ----------
function friendlyErr(msg) {
  const m = String(msg || "");
  if (m === "LOCKED") return "文件被占用或权限不足，无法移入回收站";
  if (m === "TOO_LARGE") return "文件过大（超过 5GB），回收站可能放不下，已跳过避免被永久删除";
  if (/denied|access|拒绝|权限/i.test(m)) return "权限不足（可能被占用或需要管理员权限）：" + m;
  if (/illegal|非法|invalid|无效/i.test(m)) return "路径无效：" + m;
  return m || "未知错误";
}
async function recycleDelete(paths) {
  const ok = [], fail = [];
  const valid = [];
  const sizes = new Map();
  for (const raw of paths) {
    const p = path.resolve(raw);
    if (!onDrive(p)) { fail.push({ path: raw, error: "不在系统盘" }); continue; }
    if (isProtected(p)) { fail.push({ path: raw, error: "受保护路径，禁止删除" }); continue; }
    if (!fs.existsSync(p)) { fail.push({ path: raw, error: "路径不存在" }); continue; }
    valid.push(p);
    try { sizes.set(p, fs.statSync(p).size); } catch { sizes.set(p, 0); }
  }
  if (!valid.length) return { ok, fail };
  const stamp = Date.now() + "-" + Math.random().toString(36).slice(2, 6);
  const tmpJson = path.join(os.tmpdir(), "diskviz-in-" + stamp + ".json");
  const outJson = path.join(os.tmpdir(), "diskviz-out-" + stamp + ".json");
  const psFile = PS_FILE;
  fs.writeFileSync(tmpJson, JSON.stringify({ paths: valid }));
  let result;
  try {
    result = spawnSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", psFile, tmpJson, outJson], { encoding: "utf8", timeout: 120000, maxBuffer: 8 * 1024 * 1024 });
  } catch (e) {
    fs.unlinkSync(tmpJson);
    return { ok, fail: valid.map((p) => ({ path: p, error: "调用 PowerShell 失败: " + e.message })) };
  }
  fs.unlinkSync(tmpJson);
  let parsed = null;
  try {
    // PS 的 UTF8 编码会写 BOM，JSON.parse 不认，先剥掉
    parsed = JSON.parse(fs.readFileSync(outJson, "utf8").replace(/^\uFEFF/, ""));
  } catch (e) {
    console.error("[recycle] 读取 PowerShell 输出失败:", e && e.message);
  }
  try { fs.unlinkSync(outJson); } catch { /* 忽略 */ }
  if (result.status !== 0 && !parsed) {
    return { ok, fail: valid.map((p) => ({ path: p, error: "PowerShell 执行失败（退出码 " + result.status + "）" })) };
  }
  // PS 单文件时 ConvertTo-Json 输出单对象而非数组，两种情况都兼容
  const results = Array.isArray(parsed) ? parsed : (parsed ? [parsed] : []);
  const seen = new Set();
  for (const r of results) {
    seen.add(r.p);
    if (r.ok === true) ok.push({ path: r.p, size: sizes.get(r.p) || 0 });
    else fail.push({ path: r.p, error: friendlyErr(r.err) });
  }
  for (const p of valid) if (!seen.has(p)) fail.push({ path: p, error: "处理失败（无返回结果）" });
  return { ok, fail };
}

// ---------- 删除后同步更新内存树（让被删文件立刻从各视图消失） ----------
function removeFromTree(items) {
  if (!tree) return;
  const removed = new Set(items.map((i) => path.resolve(i.path)));
  const sizes = new Map(items.map((i) => [path.resolve(i.path), i.size || 0]));
  const filterList = (arr) => (arr ? arr.filter((f) => !removed.has(path.resolve(f.path))) : arr);
  tree.largest = filterList(tree.largest);
  tree.junk = filterList(tree.junk);
  tree.gameSaves = filterList(tree.gameSaves);
  tree.desktop = filterList(tree.desktop);
  tree.important = filterList(tree.important);
  for (const rp of removed) {
    const key = norm(rp);
    const node = tree.dirs.get(key);
    if (node) {
      // 删除的是目录：移除其整棵子树，并向上递减祖先大小
      const sub = [...tree.dirs.keys()].filter((k) => k === key || k.startsWith(key + "\\"));
      let sz = 0, fc = 0;
      for (const k of sub) { const n = tree.dirs.get(k); if (n) { sz += n.size; fc += n.fileCount; } tree.dirs.delete(k); }
      let p = node.parent;
      while (p) { const pn = tree.dirs.get(p); if (!pn) break; pn.size = Math.max(0, pn.size - sz); pn.fileCount = Math.max(0, pn.fileCount - fc); p = pn.parent; }
    } else {
      // 删除的是文件：向上递减其所在目录链（大小用删除前记录的）
      let sz = sizes.get(rp);
      if (!sz) { try { sz = fs.lstatSync(rp).size; } catch { sz = 0; } }
      let p = norm(path.dirname(rp));
      while (p) { const pn = tree.dirs.get(p); if (!pn) break; pn.size = Math.max(0, pn.size - sz); pn.fileCount = Math.max(0, pn.fileCount - 1); p = pn.parent; }
    }
  }
  const rootNode = tree.dirs.get(norm(tree.summary.root));
  if (rootNode) { tree.summary.totalSize = rootNode.size; tree.summary.totalFiles = rootNode.fileCount; }
}

// ---------- HTTP ----------
function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(body);
}
async function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = "";
    req.on("data", (c) => { d += c; if (d.length > 5e6) { reject(new Error("body too large")); req.destroy(); } });
    req.on("end", () => { try { resolve(d ? JSON.parse(d) : {}); } catch (e) { reject(e); } });
    req.on("error", reject);
  });
}
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon" };

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, "http://x");
  const p = u.pathname;
  try {
    if (p === "/api/status") return send(res, 200, {
      scan: scan ? { running: scan.running, root: scan.root, doneDirs: scan.doneDirs, doneFiles: scan.doneFiles, bytes: scan.bytes, current: scan.current, cancelled: scan.cancelled, error: scan.error } : null,
      summary: tree?.summary ?? null, hasTree: !!tree,
    });
    if (p === "/api/scan" && req.method === "POST") {
      const body = await readBody(req);
      const root = path.resolve(body.root || DEFAULT_ROOT);
      if (!onDrive(root)) return send(res, 400, { error: "必须扫描系统盘路径" });
      const r = startScan(root);
      return send(res, r.ok ? 202 : 409, r);
    }
    if (p === "/api/stop" && req.method === "POST") return send(res, 200, stopScan());
    if (p === "/api/tree") {
      if (!tree) return send(res, 409, { error: "尚未扫描完成" });
      const d = treeChildren(u.searchParams.get("dir") || tree.summary.root);
      return d ? send(res, 200, d) : send(res, 404, { error: "目录不在扫描结果中" });
    }
    if (p === "/api/largest") {
      if (!tree) return send(res, 409, { error: "尚未扫描完成" });
      const n = Math.min(Number(u.searchParams.get("n") || 200), 2000);
      return send(res, 200, { items: tree.largest.slice(0, n) });
    }
    if (p === "/api/junk") {
      if (!tree) return send(res, 200, { items: [], scanned: false });
      const ADMIN_RE = /^c:\\windows(?:\\|$)|^c:\\program files|^c:\\programdata/i;
      return send(res, 200, { items: tree.junk.map((f) => ({ ...f, admin: ADMIN_RE.test(norm(f.path)) })), scanned: true });
    }
    if (p === "/api/recommended") {
      if (!tree) return send(res, 200, { items: [], scanned: false });
      const ADMIN_RE = /^c:\\windows(?:\\|$)|^c:\\program files|^c:\\programdata/i;
      const items = tree.junk.map((f) => ({ ...f, admin: ADMIN_RE.test(norm(f.path)) }));
      return send(res, 200, { items, scanned: true });
    }
    if (p === "/api/important") return send(res, 200, { items: tree?.important ?? [], scanned: !!tree });
    if (p === "/api/gamesaves") return send(res, 200, { items: tree?.gameSaves ?? [], scanned: !!tree });
    if (p === "/api/desktop") return send(res, 200, { items: tree?.desktop ?? [], scanned: !!tree });
    if (p === "/api/trash") return send(res, 200, { ops: listTrash() });
    if (p === "/api/delete" && req.method === "POST") {
      const b = await readBody(req);
      if (!Array.isArray(b.paths) || !b.paths.length) return send(res, 400, { error: "需要 paths 数组" });
      // 二选一：dest = "trash"（应用回收站，可撤回，默认）| "recycle"（Windows 系统回收站）
      const r = b.dest === "recycle" ? await recycleDelete(b.paths) : await deletePaths(b.paths);
      if (r.ok.length) removeFromTree(r.ok); // 让被删文件立刻从视图消失并联动更新总大小
      return send(res, 200, r);
    }
    if (p === "/api/restore" && req.method === "POST") {
      const b = await readBody(req);
      if (!Array.isArray(b.items) || !b.items.length) return send(res, 400, { error: "需要 items 数组" });
      return send(res, 200, await restoreItems(b.items));
    }
    if (p === "/api/undo" && req.method === "POST") return send(res, 200, await undoLast());
    if (p === "/api/empty-trash" && req.method === "POST") {
      const b = await readBody(req);
      if (b.confirm !== true) return send(res, 400, { error: "需要确认" });
      return send(res, 200, await emptyTrash());
    }
    if (p === "/api/reveal" && req.method === "POST") {
      const b = await readBody(req);
      if (!b.path) return send(res, 400, { error: "需要 path" });
      const target = path.resolve(b.path);
      if (!fs.existsSync(target)) return send(res, 404, { error: "路径不存在" });
      spawn("explorer.exe", ["/select,", target], { detached: true, stdio: "ignore" }).unref();
      return send(res, 200, { ok: true });
    }
    // 静态文件（SEA 单文件 exe 时从嵌入资源读取 index.html）
    if (p === "/" || p === "/index.html") {
      if (IS_SEA && SEA && typeof SEA.getAsset === "function") {
        try {
          // Node 24 的 getAsset 返回 ArrayBuffer，需转 Buffer 才能 res.end
          const buf = Buffer.from(SEA.getAsset("index.html"));
          res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
          return res.end(buf);
        } catch (e) {
          console.error("[sea] getAsset(index.html) 失败:", e && e.message);
        }
      }
      try {
        const f = path.join(PUBLIC_DIR, "index.html");
        if (!fs.existsSync(f)) {
          res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
          return res.end("index.html 未找到（打包版需内嵌资源或与 public/ 同目录）");
        }
        return fs.createReadStream(f).pipe(res);
      } catch (e) {
        console.error("[static] 提供 index.html 失败:", e && e.message);
        res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
        return res.end("内部错误");
      }
    }
    const file = path.join(PUBLIC_DIR, p.replace(/^\/+/, ""));
    if (file.startsWith(PUBLIC_DIR) && fs.existsSync(file) && fs.statSync(file).isFile()) {
      res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-store" });
      return fs.createReadStream(file).pipe(res);
    }
    send(res, 404, { error: "not found" });
  } catch (e) {
    send(res, 500, { error: String(e && e.message || e) });
  }
});

fs.mkdirSync(TRASH_DIR, { recursive: true });
server.on("error", (e) => {
  if (e.code === "EADDRINUSE") {
    console.error("");
    console.error("[错误] 端口 " + PORT + " 已被占用——可能已有 DiskViz 实例在运行。");
    console.error("      请直接打开 http://127.0.0.1:" + PORT + " 使用现有实例，");
    console.error("      或先关闭旧的 DiskViz 窗口/进程再重新启动。");
    process.exit(1);
  }
  throw e;
});
server.listen(PORT, "127.0.0.1", () => {
  const url = `http://127.0.0.1:${PORT}`;
  console.log("DiskViz 磁盘可视化清理助手已启动");
  console.log("请在浏览器打开: " + url);
  console.log("扫描根目录: " + DEFAULT_ROOT + "   (可用环境变量 SCAN_ROOT 修改)");
  console.log("回收站目录: " + TRASH_DIR + "   (删除的文件都先进这里，可随时恢复)");
  // 自动打开浏览器
  setTimeout(() => {
    try { spawn("cmd", ["/c", "start", "", url], { detached: true, stdio: "ignore" }).unref(); } catch { /* 忽略 */ }
  }, 800);
});
